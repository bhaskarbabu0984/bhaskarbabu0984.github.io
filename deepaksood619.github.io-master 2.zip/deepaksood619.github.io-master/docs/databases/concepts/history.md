# History

![image](../../media/History-image1.jpg)

![image](../../media/History-image2.jpg)

![image](../../media/History-image3.jpg)

![image](../../media/History-image4.jpg)

![image](../../media/History-image5.jpg)

![image](../../media/History-image6.jpg)

![image](../../media/History-image7.jpg)

![image](../../media/History-image8.jpg)

![image](../../media/History-image9.jpg)

![image](../../media/History-image10.jpg)

![image](../../media/History-image11.jpg)

![image](../../media/History-image12.jpg)

![image](../../media/History-image13.jpg)

![image](../../media/History-image14.jpg)

![image](../../media/History-image15.jpg)

![image](../../media/History-image16.jpg)

[01 - History of Databases (CMU Databases / Spring 2020)](https://www.youtube.com/watch?v=SdW5RKUboKc)

[Databases in 2023: A Year in Review | OtterTune](https://ottertune.com/blog/2023-databases-retrospective)
