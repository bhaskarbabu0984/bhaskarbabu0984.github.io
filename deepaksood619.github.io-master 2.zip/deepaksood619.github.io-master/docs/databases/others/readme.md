# Others

- [Database Activity Monitoring (DAM)](databases/others/database-activity-monitoring-dam.md)
- [Databases - Others](databases-others)
- [Database Migration Tools](databases/others/database-migration-tools.md)
- [Technologies / Tools](technologies-tools)
- [Course AWS Certified Database Specialty](course-aws-certified-database-specialty)
- [Course Advanced Database Systems](course-advanced-database-systems)
