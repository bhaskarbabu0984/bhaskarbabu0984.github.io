# Sales

- Feet on street

## Sales model

In a bottoms-up model, engineers within an enterprise start using your product to solve a well-defined problem such as API management. As more and more employees within the organization start to use your prodct, you can begin to engage the enterprise about becoming a paying customer for your product for your product. Since the enterprise is already using your prouct, the sales conversation is much easier.

In the top-down model, you engage the CIO, CEO, or CTO directly and try to convince them that your product is worth paying for. When the senior leadership of a bank buys into your product idea, you can count on that senior leadership to convince their developers to use your product within the bank.

## Tools

- Zoominfo
- LinkedIn Sales navigator
- [Apollo.io](http://apollo.io/)

## Links

- [The Mom Test](book-summaries/the-mom-test.md)
- [5 Sales Email Templates That Really Work | LinkedIn](https://business.linkedin.com/sales-solutions/resources/five-sales-email-templates)
- [Google Trends for Marketing & Sales - YouTube](https://www.youtube.com/watch?v=HzHd2vusBRg)
- [Google Trends Advanced Tips - YouTube](https://www.youtube.com/watch?v=Kkd2PkbCdSc)
