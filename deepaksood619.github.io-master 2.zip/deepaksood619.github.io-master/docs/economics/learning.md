# Learning

## Course - Corporate Governance

[Facebook (Meta) Lesson 1: Corporate Governance - The What, Why and What now?](https://www.youtube.com/watch?v=ouxmdkMWWmI)

[Facebook (Meta) Lesson 2: Accounting Inconsistencies and Consequences](https://www.youtube.com/watch?v=QWIqmZ6NbMA&t)

## Links

[Fundamentals of Finance & Economics for Businesses - Crash Course - YouTube](https://www.youtube.com/watch?v=EJHPltmAULA)
