# Power

Power tends to corrupt, absolute power corrupts absolutely

It is not power that corrupts but fear. Fear of losing power corrupts those who wield it and fear of the scourge of power corrupts those who are subject to it.

[48 Laws of Power](../book-summaries/48-laws-of-power)

[David and Goliath](../book-summaries/david-and-goliath)

## Persuasion and Authority

Be mindful of the principles of persuasion. No one trusts a doctor who shows up in a skater outfit. But if a skater puts on a white lab coat and carries a doctor bag, we instantly think it's a doctor.

Since people are too busy to study everything in detail or weigh all the pros and cons before making a purchase, they rely on the simplified idea of authority. If someone is trusted by our peers, we also instantly trust them.

https://dariusforoux.com/authority
