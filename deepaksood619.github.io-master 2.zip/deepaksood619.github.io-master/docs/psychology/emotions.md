# Emotions

## Emotion Wheels

![Emotion Wheel I](../media/Pasted%20image%2020230514131840.jpg)

![Emotion Wheel II](../media/Pasted%20image%2020230514131848.jpg)

![Emotion Wheel III - Uncomfortable Emotions](../media/Pasted%20image%2020230514131857.jpg)

![Emotion Wheel III - Comfortable Emotions](../media/Pasted%20image%2020230514131906.jpg)

![HS Needs Wheel I](../media/Pasted%20image%2020230514131917.jpg)

![HS Needs Wheel II](../media/Pasted%20image%2020230514131925.jpg)

[Emotion Wheels & Needs Wheel - Human Systems](https://humansystems.co/emotionwheels/)

[The Emotion Wheel: What It Is and How to Use It](https://positivepsychology.com/emotion-wheel/)

[Emotion Wheel: What it is and How to Use it to Get to Know Yourself](https://www.betterup.com/blog/emotion-wheel)

## Links

[Why you feel what you feel | Alan Watkins | TEDxOxford - YouTube](https://www.youtube.com/watch?v=h-rRgpPbR5w&ab_channel=TEDxTalks)

[How We Became the Loneliest Generation - YouTube](https://youtu.be/I19btmIBhx0?si=0ketcMZ3fk3H-cDz)

- Disappearance of Third places
