# Patricia Trie

![image](../../media/Patricia-Trie-image1.jpg)
