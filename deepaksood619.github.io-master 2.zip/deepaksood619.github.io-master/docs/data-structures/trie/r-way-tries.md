# R-way Tries

![image](../../media/R-way-Tries-image1.jpg)

![image](../../media/R-way-Tries-image2.jpg)

![image](../../media/R-way-Tries-image3.jpg)

![image](../../media/R-way-Tries-image4.jpg)

![image](../../media/R-way-Tries-image5.jpg)

![image](../../media/R-way-Tries-image6.jpg)

![image](../../media/R-way-Tries-image7.jpg)

![image](../../media/R-way-Tries-image8.jpg)

![image](../../media/R-way-Tries-image9.jpg)

![image](../../media/R-way-Tries-image10.jpg)

![image](../../media/R-way-Tries-image11.jpg)

![image](../../media/R-way-Tries-image12.jpg)

![image](../../media/R-way-Tries-image13.jpg)

![image](../../media/R-way-Tries-image14.jpg)

![image](../../media/R-way-Tries-image15.jpg)
