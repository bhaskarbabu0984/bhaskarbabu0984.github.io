# Questions

- Count total number of words in Trie
- Print all words stored in Trie
- Sort elements of an array using Trie
- Form words from a dictionary using Trie
- Build a T9 dictionary

![image](../../media/ds-Questions-image1.jpg)

![image](../../media/ds-Questions-image2.jpg)

![image](../../media/ds-Questions-image3.jpg)

![image](../../media/Questions-image4.jpg)

![image](../../media/Questions-image5.jpg)
