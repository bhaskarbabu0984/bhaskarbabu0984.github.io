# Ternary Search Tries (TST)

Solve the problem of using large amount of data by R-way tries.
Exactly 3 children.
Creating associative Symbol table

![image](../../media/Ternary-Search-Tries-(TST)-image1.jpg)

![image](../../media/Ternary-Search-Tries-(TST)-image2.jpg)

![image](../../media/Ternary-Search-Tries-(TST)-image3.jpg)

![image](../../media/Ternary-Search-Tries-(TST)-image4.jpg)

![image](../../media/Ternary-Search-Tries-(TST)-image5.jpg)

![image](../../media/Ternary-Search-Tries-(TST)-image6.jpg)

![image](../../media/Ternary-Search-Tries-(TST)-image7.jpg)

![image](../../media/Ternary-Search-Tries-(TST)-image8.jpg)

![image](../../media/Ternary-Search-Tries-(TST)-image9.jpg)

![image](../../media/Ternary-Search-Tries-(TST)-image10.jpg)

![image](../../media/Ternary-Search-Tries-(TST)-image11.jpg)

Very easy to speed up and saves a lot of data.

![image](../../media/Ternary-Search-Tries-(TST)-image12.jpg)

![image](../../media/Ternary-Search-Tries-(TST)-image13.jpg)

![image](../../media/Ternary-Search-Tries-(TST)-image14.jpg)
