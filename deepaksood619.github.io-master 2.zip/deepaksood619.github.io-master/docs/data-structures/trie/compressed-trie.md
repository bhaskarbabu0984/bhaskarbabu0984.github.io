# Compressed Trie

Compressed Trie is obtained from standard trie by joining chains of single nodes. The nodes of a compressed trie can be stored by storing index ranges at the nodes

![image](../../media/Compressed-Trie-image1.jpg)
