# Adjacency Matrix

![image](../../media/Adjacency-Matrix-image1.jpg)
