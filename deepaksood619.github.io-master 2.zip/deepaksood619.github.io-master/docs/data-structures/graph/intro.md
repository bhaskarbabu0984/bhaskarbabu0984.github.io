# Intro

## Representation

1. Adjacency Matrix
2. Adjacency List

![image](../../media/ds-Intro-image1.jpg)

## Graph types

1. Sparse graph
2. Dense graph

![image](../../media/ds-Intro-image2.jpg)
