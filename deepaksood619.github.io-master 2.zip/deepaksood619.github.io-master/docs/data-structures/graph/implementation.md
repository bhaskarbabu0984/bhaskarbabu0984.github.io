# Implementation

## Python

Use dictionary to represent a graph in Python

```python
graph = { "a" : ["c"],
        "b" : ["c", "e"],
        "c" : ["a", "b", "d", "e"],
        "d" : ["c"],
        "e" : ["c", "b"],
        "f" : []
    }
```
