# Adjacency List

![image](../../media/Adjacency-List-image1.jpg)

![image](../../media/Adjacency-List-image2.jpg)
