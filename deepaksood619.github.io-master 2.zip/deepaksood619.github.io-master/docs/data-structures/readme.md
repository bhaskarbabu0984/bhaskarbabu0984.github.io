# Data Structures

- [General](general/readme.md)
- [Linear Data Structure](linear-data-structure/readme.md)
- [Hierarchical Data Structure](hierarchical-data-structure/readme.md)
- [Graph](graph/readme.md)
- [HashTable](hashtable/readme.md)
- [Trie](trie/readme.md)
- [Others](data-structures/others/readme.md)
