# Dictionaries

![image](../../media/Dictionaries-image1.jpg)

![image](../../media/Dictionaries-image2.jpg)

![image](../../media/Dictionaries-image3.jpg)

![image](../../media/Dictionaries-image4.jpg)
