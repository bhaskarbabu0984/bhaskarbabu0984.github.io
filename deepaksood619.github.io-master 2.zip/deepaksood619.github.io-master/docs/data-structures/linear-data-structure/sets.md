# Sets

Application of Symbol table.

## Sets

A collection of distinct keys

Application - Exception filter

- Read in a list of words from one file
- Print out all words from standard input that are `{in, not in}` the list
    - Whitelist a set of strings or objects
    - Blacklist a set of strings or objects

Application of Exception filter -

- Spell checker
- Browser
- Parental controls
- Chess
- Spam filter
- Credit cards
