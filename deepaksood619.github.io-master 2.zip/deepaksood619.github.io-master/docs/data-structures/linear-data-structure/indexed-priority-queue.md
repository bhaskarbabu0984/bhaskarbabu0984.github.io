# Indexed Priority Queue

![image](../../media/Indexed-Priority-Queue-image1.jpg)

![image](../../media/Indexed-Priority-Queue-image2.jpg)

## Applications

- Prim's Algorithm
