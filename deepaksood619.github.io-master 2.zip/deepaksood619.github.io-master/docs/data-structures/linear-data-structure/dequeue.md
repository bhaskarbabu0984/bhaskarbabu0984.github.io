# Dequeue

## Dequeue

A *double-ended queue* or *deque* (pronounced "deck") is a generalization of a stack and a queue that supports adding and removing items from either the front or the back of the data structure

Dequeue - double ended queue

- Insert items from any end
- Get items from any end
