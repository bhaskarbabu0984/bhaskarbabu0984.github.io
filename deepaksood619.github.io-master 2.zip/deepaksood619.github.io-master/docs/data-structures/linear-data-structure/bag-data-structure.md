# Bag Data Structure

Application - Adding items to a collection and iterating (When order doesn't matter)
Implementation - Stack (without pop) or queue (without dequeue)
