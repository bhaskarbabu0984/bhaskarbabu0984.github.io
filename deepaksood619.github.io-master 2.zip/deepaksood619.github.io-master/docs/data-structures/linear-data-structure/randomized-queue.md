# Randomized Queue

## Randomized queue

A *randomized queue* is similar to a stack or queue, except that the item removed is chosen uniformly at random from items in the data structure
