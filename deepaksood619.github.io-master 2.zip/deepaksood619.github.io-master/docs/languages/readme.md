# Languages

- [Python](python/readme.md)
- [SQL](sql/readme.md)
- [C++](c++/readme.md)
- [Java](java/readme.md)
- [PHP](php/readme.md)
- [Golang](golang/readme.md)
- [Frameworks](frameworks/readme.md)
- [Others](languages/others/readme.md)

## Links

[PYPL PopularitY of Programming Language index](https://pypl.github.io/PYPL.html)
