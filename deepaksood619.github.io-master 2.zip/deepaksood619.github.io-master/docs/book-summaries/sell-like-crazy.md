# Sell Like Crazy

By Sabri Suby

- **Find Customers Hopes and dreams, pains and fears, barriers and strategies**
- **Top 4% gives 64% of revenue**
- **HVCO (High Value Content Offer)**
    - Attention grabing headline
    - Every point touches a burning issue
    - Keep it simple
- How to X when Y
- Compelling image
- Free cheatsheets if you give your email
- Offer that customers cannot refuse (crazy offer) - Godfather offer
    - Rationale why are you making that offer
    - Build value
    - Break the final value down to daily / weekly figure
    - Price for a coffee per day you get X
    - Give 3 offers
    - Premium
    - Free gifts
    - If you order right now you get x too
    - Power guarantee (12 months guarantee)
    - Scaricity (countdown, only X are left)
- Mutiple Traffic channels
- Only when you know how much you make off a customer, you will know how much you can spend to get one
- Magic lantern technique (2-3 videos with pure values - informs what problems your service solves)
- Add CTA (Call To Action)

[Sell Like Crazy Summary and Review | Book by Sabri Suby - StoryShots](https://www.getstoryshots.com/books/sell-like-crazy-summary/)
