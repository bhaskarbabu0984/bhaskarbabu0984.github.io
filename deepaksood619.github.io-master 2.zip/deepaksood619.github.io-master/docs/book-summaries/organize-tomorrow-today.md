# Organize Tomorrow Today

By Jason Selk & Tom Bartow

- Highly successful people rarely complete everything they want to do in a given day, but they always get the most important things done each day.

- Forgot about everything except, hard work and intelligent planning

- Maximize your time each day
- If you do your job, the score takes care of itself

- MIT - Most Important Task

- The ideal time to prioritize tomorrow is today
- 3 most important & 1 most (3 & 1)

- Expect the unexpected tomorrow

- When your day deviates from your plan, Regain control & rebuild momentum
- 1. The 100 second timeout
- 2. Ask and chop

- Make each day your masterpiece

[ORGANIZE TOMORROW TODAY by Jason Selk & Tom Bartow | Core Message](https://youtu.be/yRLEr69qPd4)
