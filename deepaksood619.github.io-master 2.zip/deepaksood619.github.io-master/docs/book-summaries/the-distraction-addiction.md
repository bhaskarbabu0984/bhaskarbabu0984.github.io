# The Distriction Addiction

By Alex Soojung-Kim Pang

- Boost your productivity by distinguishing betwen multitasking and "switch-tasking"
    - Multitasking is doing a lot of different works that are related to each other for achieving a common goal (like organizing a dinner party)
    - Switch Tasking is not an effective way to do things
- Distraction is a choice
    - Distraction isn't a product of the external world, but the reflection of an inner state
    - If you start out on a task with a distracted mind, you're much more likely to be distracted when your phone buzzes
- Mindfulness
- We connect more as computers become more interactive, and that can help us reach our goals
- Walking and contemplative design can help us focus and block out distractions
- Discover greater meaning in your life by identifying addictive distractions and switching them off
- Attentiveness to the task at hand is an ability honed over time by both willpower and mindfulness

[Why your phone is making you sad - YouTube](https://www.youtube.com/watch?v=vcjQ5JkEE_0)
