# Off the Clock

By Laura Vanderkam

Feel less busy while getting more done

- Learn exactly what you're doing with your time, even if it scares you, by keeping a log
- Make your hours memorable by filling them with exciting moments
- Our own insecurities keep us constantly busy, so learn to free up your calendar
- Spending time with loved ones can stretch our perception of time, and may even increase our lifespan
- *Accept the constraints on your time and lower your expectations*
- Spend your money on enlargin pleasant experiences and minimizing bad ones
- Have time for adventures
    - Figure out where the time actually goes
    - Plan in little adventures
    - Be careful with **yes**
    - Slow down
    - Put friends on your calendar
