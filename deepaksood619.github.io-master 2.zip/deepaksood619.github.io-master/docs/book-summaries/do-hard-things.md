# Do Hard Things

By Steve Magness

- Traditional Toughness - Act Confident
- Science of Toughness - Embrace reality
- An ounce of doubt keeps me sharp.
- Assume nothing will happen as smothly or easily as you hope, but with enough time and effort it will get done.
- Traditional Toughness - Ignore the pain and push on
- The science of toughness - Acknowledge the pain but maitain equanimity
- Reappriase - How might discomfort be beneficial
- Reassure - This too shall pass
- Traditional toughness - Forget the psychological needs and just do the work
- The science of toughness - Satisfy the psychological needs and you'll work harder than ever

[DO HARD THINGS by Steve Magness | Core Message](https://www.youtube.com/watch?v=PyosFtMazPo)
