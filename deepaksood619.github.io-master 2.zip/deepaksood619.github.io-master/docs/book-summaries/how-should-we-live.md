# How should we live?

By Roman Krznaric

- Love
    - **Eros**, the fiery, passionate yet dangerous love
    - **Philia**, the platonic love between friends and comrades
    - **Ludus**, the playfulness that is found among new lovers and children
    - **Pragma**, the deep understanding that grows over time between partners
    - **Agape**, the selfless, charitable love for our fellow humans
    - **Philautia**, the love of the self, which could be either a positive acceptance or a detrimental self-obsession

Rather than relying on one partner to satisfy all these needs, the ancient Greeks believed that each role could be fullfilled by different individuals.

- Husband means House Bound
- Talk on dinner table about emotions
- Monotonous work
- Pin factory method for dividing work
- Obsession with time
- Consumerism
- Travel is a great way to learn about yourself, and broaden our world view
- Can take a trip near and don't waste fuel going to carribean
