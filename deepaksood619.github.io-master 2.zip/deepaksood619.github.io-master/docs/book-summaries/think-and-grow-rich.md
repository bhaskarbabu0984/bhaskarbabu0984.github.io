# Think and Grow Rich

By Napolean Hill

The 13 "steps" listed in the book are:

1. Desire
2. Faith
3. **Autosuggestion**
4. Specialized Knowledge
5. Imagination
6. Organized Planning
7. Decision
8. Persistence
9. Power of the Master Mind
10. The Mystery of Sex Transmutation
11. The Subconscious Mind
12. The Brain
13. The Sixth Sense

Two most important laws/principle

1. The master mind principle/process
2. Know very clearly where you want to go

Others

1. Shakespherian text (appreciate your opponent's work whom you are going to critize and then slowly when audience is on your side, show them the flaw)
2. Positive suggestions
3. Self confidence (use affirmations)
