# Get it

By Amy K Hutchens

Get It: Five Steps to the Sex, Salary and Success You Want

- You will have more profitable conversations with others if you're honest with yourself
- In general, conversations are about either connection or power (assert)
- The best way to deal with power plays at work is to refust to engage with them
- You're unlikely to get what you want from someone if you offend their ego
- You can use the deflate technique to avoid explosive arguments
- Making requests and asking questions are great ways to motivate action
