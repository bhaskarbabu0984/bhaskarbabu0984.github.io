# Leaders Eat Last

By Simon Sinek

- Endorphin: The hormone that masks pain
- Dopamine: The hormone that helps us accomplish things
- Serotonin: The leadership hormone
- Oxytocin: The love hormone

- Endorphin and Dopamine - Selfish hormones
    - Dopamine - It rewards us with intense happiness every time we complete a task
    - Endorphins - disguise exhaustion and physical pain and can fool us mentally so that we can go further, even after significant physical efforts
    - When you finish an exercise feeling good, and the next day the whole body hurts? It did not hurt right away because of the released endorphin, which increased its performance
- Serotonin and oxytocin - Altruistic hormones - Affect our social life, helping us relate to others
