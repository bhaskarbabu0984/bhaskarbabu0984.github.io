# The 4 Agreements

### Agreement 1: Be impeccable with your Word

- Your words are powerful
- The word can enter our mind and change a whole belief for better or for worse.
- The word casts spells
- You are what you consume
- Gossip is black magic and pure poison

### Agreement 2: Don't take anything personally

- Don't take things personally
- About them vs about you
- When everything around you is great, everything makes you happy
- We make agreements to help each other suffer
- Keep the agreements with yourself

### Agreement 3: Don't make assumptions

- We have the tendency to make assumptions about everything
- Why we shouldn't make assumptions
- We make the assumption that we know what the other person wants
- What is Real Love
- If you don't understand something, ask questions

### Agreement 4: Always do your best

- Your best will become better than it used to be
- Action VS Reward
- Forrest Gump
- The first three rely on the fourth
- Master through repetition

[The Four Agreements by Don Miguel Ruiz | (Detailed Book Summary) - YouTube](https://www.youtube.com/watch?v=gpwuq5wOvwI)
