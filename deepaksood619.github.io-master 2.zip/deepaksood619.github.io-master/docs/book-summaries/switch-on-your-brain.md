# Switch on your brain

- Watch your thoughts - for they become your actions, which, in turn, become your character and destiny
- Free will is not an illusion
- Humans are the only one that can think about thinking - Multiple Perspective Advantage, MPA

- **21-day Brain Detox Plan**

  1. Gather

     - Becoming aware of all the signals that are coming into your mind from the external environment through the five senses and understanding the internal environment of your mind
     - Identify a toxic thought pattern and consciously think of a replacement thought

  2. Focused Reflection

     - Loosen up "the branches" of the respective thought tree
     - It is about growing and integrating healthy branches by reflecting on the positive immediately after dwelling on the negative

  3. Write

     - Write down your thoughts to add some clarity to their expression

  4. Revisit

     - Replace a toxic thought with a healthy one

  5. Active Reach

     - Every two hours, remind yourself of your replacement thought
     - What you starve die off and what you feed will grow
