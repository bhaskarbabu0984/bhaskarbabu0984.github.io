# The power of Concentration

By Thereon Q Dumont

- Peace of Mind
- I have the power to do and to be whatever I wish to do and be.
- Just the minute you are aware of thinking a negative thought immediately change to a positive one. If you start to think of failure, change to thinking of success.
- Think, speak and act just as you wish to be, And you will be that which you wish to be.
- No one can limit us but overselves.

"I am going to try today not to make a useless gesture or to worry over trifles, or become nervous or irritable. I intend to be calm, and, no difference what may be the circumstances, I will control myself. Henceforth I resolve to be free from all signs that show lack of self-control."
