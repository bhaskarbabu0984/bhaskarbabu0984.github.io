# Github

Organizations

If you're using GitHub Free, you can add unlimited collaborators on public and private repositories.

## Links

[Github Actions - Workflow automation](devops/others/other-cicd.md)

[Managing user access to your organization's repositories - GitHub Docs](https://docs.github.com/en/organizations/managing-user-access-to-your-organizations-repositories)
