# FastTag

[Fastag Service | Fastag Integration API](https://zuelpay.in/FasTag_API)

[Fastag | API Developer Portal](https://apiportal.axisbank.com/portal/product/3699)

[**FASTag API reference** - Setu Docs](https://docs.setu.co/payments/fastag/api-reference)

![fasttag-api-reference](../../media/Pasted%20image%2020231213213203.jpg)

### Fast Tags at petrol pumps

[FASTags to be made available from petrol stations - IndBiz | Economic Diplomacy Division | IndBiz | Economic Diplomacy Division](https://indbiz.gov.in/fastags-to-be-made-available-from-petrol-stations/)

[Fastag Fuel Payments - ICICI Bank](https://www.icicibank.com/personal-banking/cards/prepaid-card/fastag/fuel-payments)

### Others

- Payment Gateway Integration
- FastTag reseller
