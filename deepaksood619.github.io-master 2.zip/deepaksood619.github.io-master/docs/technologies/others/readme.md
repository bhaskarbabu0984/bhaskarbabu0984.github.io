# Others

- [Presto](presto)
- [FastTag](technologies/others/fasttag.md)
- [Others - IoT](others-iot)
- [Others - Distributed Systems](others-distributed-systems)
- [Others](other-technologies.md)
