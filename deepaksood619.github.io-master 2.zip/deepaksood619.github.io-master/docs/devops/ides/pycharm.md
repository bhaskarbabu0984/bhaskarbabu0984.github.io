# PyCharm

## Shortcuts Mac

Push - command + shift + k

Commit - command + k

## Multicursor

alt twice and hold + Up/Down arrow

https://www.jetbrains.com/help/pycharm/multicursor.html
