# IDEs

- [VSCode / VS Code](vscode-vs-code)
- [Spyder](spyder)
- [Pycharm](pycharm)
- [Jupyter / Jupyterlab / Notebook](jupyter-jupyterlab-notebook/readme.md)
    - [Jupyterlab tools](jupyter-jupyterlab-notebook/tools)
    - [Template](jupyter-jupyterlab-notebook/template)
- [Mac](mac)
- [OneNote](onenote)
- [Obsidian](obsidian)
- [Obsidian in VSCode](obsidian-in-vscode)
- [Medium Blogging](medium-blogging)
- [Others](devops/ides/others.md)
