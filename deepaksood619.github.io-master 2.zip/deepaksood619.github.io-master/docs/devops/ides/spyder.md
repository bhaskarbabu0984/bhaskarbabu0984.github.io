# Spyder

Here you can get help of any object by pressing**Cmd+I**in front of it, either on the Editor or the Console.

Help can also be shown automatically after writing a left parenthesis next to an object. You can activate this behavior in*Preferences > Help*.
