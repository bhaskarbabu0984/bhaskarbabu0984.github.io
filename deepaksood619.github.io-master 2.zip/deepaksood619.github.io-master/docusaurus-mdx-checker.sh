#!/bin/bash
echo "Running docusaurus-mdx-checker"
npx docusaurus-mdx-checker
